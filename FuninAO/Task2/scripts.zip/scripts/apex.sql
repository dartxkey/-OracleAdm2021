SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/apex.log append
@/oracle/db/ohome/apex/catapx.sql change_on_install SYSAUX SYSAUX TEMP /i/ NONE;
spool off
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/postDBCreation.log append
grant sysdg to sysdg;
grant sysbackup to sysbackup;
grant syskm to syskm;
