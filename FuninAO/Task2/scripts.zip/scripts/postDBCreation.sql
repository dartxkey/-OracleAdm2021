SET VERIFY OFF
spool /oracle/db/admin/oracleadm/scripts/postDBCreation.log append
@/oracle/db/ohome/rdbms/admin/catbundle.sql psu apply;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
create spfile='/oracle/db/ohome/dbs/spfileoracleadm.ora' FROM pfile='/oracle/db/admin/oracleadm/scripts/init.ora';
connect "SYS"/"&&sysPassword" as SYSDBA
select 'utlrp_begin: ' || to_char(sysdate, 'HH:MI:SS') from dual;
@/oracle/db/ohome/rdbms/admin/utlrp.sql;
select 'utlrp_end: ' || to_char(sysdate, 'HH:MI:SS') from dual;
select comp_id, status from dba_registry;
shutdown immediate;
connect "SYS"/"&&sysPassword" as SYSDBA
startup ;
spool off
exit;
