SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/spatial.log append
@/oracle/db/ohome/md/admin/mdinst.sql;
spool off
