SET VERIFY OFF
set echo on
spool /oracle/db/admin/oracleadm/scripts/cwmlite.log append
connect "SYS"/"&&sysPassword" as SYSDBA
@/oracle/db/ohome/olap/admin/olap.sql SYSAUX TEMP;
spool off
