SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/CreateDBCatalog.log append
@/oracle/db/ohome/rdbms/admin/catalog.sql;
@/oracle/db/ohome/rdbms/admin/catblock.sql;
@/oracle/db/ohome/rdbms/admin/catproc.sql;
@/oracle/db/ohome/rdbms/admin/catoctk.sql;
@/oracle/db/ohome/rdbms/admin/owminst.plb;
connect "SYSTEM"/"&&systemPassword"
@/oracle/db/ohome/sqlplus/admin/pupbld.sql;
connect "SYSTEM"/"&&systemPassword"
set echo on
spool /oracle/db/admin/oracleadm/scripts/sqlPlusHelp.log append
@/oracle/db/ohome/sqlplus/admin/help/hlpbld.sql helpus.sql;
spool off
spool off
