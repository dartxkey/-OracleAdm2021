SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/interMedia.log append
@/oracle/db/ohome/ord/im/admin/iminst.sql;
spool off
