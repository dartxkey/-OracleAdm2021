SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/context.log append
@/oracle/db/ohome/ctx/admin/catctx.sql change_on_install SYSAUX TEMP LOCK;
alter user CTXSYS account unlock identified by "CTXSYS";
connect "CTXSYS"/"CTXSYS"
@/oracle/db/ohome/ctx/admin/defaults/dr0defin.sql "AMERICAN";
connect "SYS"/"&&sysPassword" as SYSDBA
alter user CTXSYS password expire account lock;
@/oracle/db/ohome/rdbms/admin/dbmsxdbt.sql;
spool off
