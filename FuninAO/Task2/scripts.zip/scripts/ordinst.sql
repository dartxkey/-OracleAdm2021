SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/ordinst.log append
@/oracle/db/ohome/ord/admin/ordinst.sql SYSAUX SYSAUX;
spool off
