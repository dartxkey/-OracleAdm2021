SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /oracle/db/admin/oracleadm/scripts/JServer.log append
@/oracle/db/ohome/javavm/install/initjvm.sql;
@/oracle/db/ohome/xdk/admin/initxml.sql;
@/oracle/db/ohome/xdk/admin/xmlja.sql;
@/oracle/db/ohome/rdbms/admin/catjava.sql;
connect "SYS"/"&&sysPassword" as SYSDBA
@/oracle/db/ohome/rdbms/admin/catxdbj.sql;
spool off
