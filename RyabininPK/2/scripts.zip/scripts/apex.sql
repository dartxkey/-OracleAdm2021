SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/apex.log append
@/u01/app/oracle/product/12.2.0/darth/apex/catapx.sql Xbkfsdcdf1ggh_123 SYSAUX SYSAUX TEMP /i/ NONE;
spool off
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/postDBCreation.log append
create or replace directory ORACLE_HOME as '/u01/app/oracle/product/12.2.0/darth';
create or replace directory ORACLE_BASE as '/u01/app/oracle';
grant sysdg to sysdg;
grant sysbackup to sysbackup;
grant syskm to syskm;
