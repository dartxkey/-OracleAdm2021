SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYS
set echo on
spool /u01/app/oracle/admin/template/scripts/sampleSchema.log append
@/u01/app/oracle/product/12.2.0/darth/demo/schema/human_resources/hr_main_new.sql Xbkfsdcdf1ggh_123 SYSAUX TEMP /u01/app/oracle/admin/template/scripts/
spool off
