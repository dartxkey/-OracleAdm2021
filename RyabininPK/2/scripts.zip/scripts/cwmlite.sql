SET VERIFY OFF
set echo on
spool /u01/app/oracle/admin/template/scripts/cwmlite.log append
connect "SYS"/"&&sysPassword" as SYSDBA
@/u01/app/oracle/product/12.2.0/darth/olap/admin/olap.sql SYSAUX TEMP;
spool off
