SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/JServer.log append
@/u01/app/oracle/product/12.2.0/darth/javavm/install/initjvm.sql;
@/u01/app/oracle/product/12.2.0/darth/xdk/admin/initxml.sql;
@/u01/app/oracle/product/12.2.0/darth/xdk/admin/xmlja.sql;
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/catjava.sql;
connect "SYS"/"&&sysPassword" as SYSDBA
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/catxdbj.sql;
spool off
