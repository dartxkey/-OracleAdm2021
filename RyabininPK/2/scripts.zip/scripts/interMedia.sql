SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/interMedia.log append
@/u01/app/oracle/product/12.2.0/darth/ord/im/admin/iminst.sql;
spool off
