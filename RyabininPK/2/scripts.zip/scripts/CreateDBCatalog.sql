SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/CreateDBCatalog.log append
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/catalog.sql;
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/catproc.sql;
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/catoctk.sql;
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/owminst.plb;
connect "SYSTEM"/"&&systemPassword"
@/u01/app/oracle/product/12.2.0/darth/sqlplus/admin/pupbld.sql;
connect "SYSTEM"/"&&systemPassword"
set echo on
spool /u01/app/oracle/admin/template/scripts/sqlPlusHelp.log append
@/u01/app/oracle/product/12.2.0/darth/sqlplus/admin/help/hlpbld.sql helpus.sql;
spool off
spool off
