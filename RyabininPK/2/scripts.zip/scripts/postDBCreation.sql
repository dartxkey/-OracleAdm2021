SET VERIFY OFF
spool /u01/app/oracle/admin/template/scripts/postDBCreation.log append
host /u01/app/oracle/product/12.2.0/darth/OPatch/datapatch -skip_upgrade_check -db template;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
create spfile='/u01/app/oracle/product/12.2.0/darth/dbs/spfiletemplate.ora' FROM pfile='/u01/app/oracle/admin/template/scripts/init.ora';
connect "SYS"/"&&sysPassword" as SYSDBA
select 'utlrp_begin: ' || to_char(sysdate, 'HH:MI:SS') from dual;
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/utlrp.sql;
select 'utlrp_end: ' || to_char(sysdate, 'HH:MI:SS') from dual;
select comp_id, status from dba_registry;
shutdown immediate;
connect "SYS"/"&&sysPassword" as SYSDBA
startup ;
spool off
exit;
