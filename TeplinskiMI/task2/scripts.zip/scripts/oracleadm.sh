#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /oracle/db/admin/oracleadm/adump
mkdir -p /oracle/db/admin/oracleadm/dpdump
mkdir -p /oracle/db/admin/oracleadm/pfile
mkdir -p /oracle/db/audit
mkdir -p /oracle/db/cfgtoollogs/dbca/oracleadm
mkdir -p /oracle/db/fast_recovery_area
mkdir -p /oracle/db/fast_recovery_area/oracleadm
mkdir -p /oracle/db/ohome/dbs
mkdir -p /oracle/db/oradata/oracleadm
umask ${OLD_UMASK}
PERL5LIB=$ORACLE_HOME/rdbms/admin:$PERL5LIB; export PERL5LIB
ORACLE_SID=oracleadm; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: oracleadm:/oracle/db/ohome:Y
/oracle/db/ohome/bin/sqlplus /nolog @/oracle/db/admin/oracleadm/scripts/oracleadm.sql
