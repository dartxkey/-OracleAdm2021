#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /u01/app/oracle
mkdir -p /u01/app/oracle/admin/template/adump
mkdir -p /u01/app/oracle/admin/template/dpdump
mkdir -p /u01/app/oracle/admin/template/pfile
mkdir -p /u01/app/oracle/audit
mkdir -p /u01/app/oracle/cfgtoollogs/dbca/template
mkdir -p /u01/app/oracle/oradata/template
mkdir -p /u01/app/oracle/product/12.2.0/darth/dbs
umask ${OLD_UMASK}
PERL5LIB=$ORACLE_HOME/rdbms/admin:$PERL5LIB; export PERL5LIB
ORACLE_SID=template; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/perl/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: template:/u01/app/oracle/product/12.2.0/darth:Y
/u01/app/oracle/product/12.2.0/darth/bin/sqlplus /nolog @/u01/app/oracle/admin/template/scripts/template.sql
