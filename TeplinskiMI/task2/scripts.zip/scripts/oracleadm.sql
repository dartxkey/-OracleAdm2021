set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
host /oracle/db/ohome/bin/orapwd file=/oracle/db/ohome/dbs/orapworacleadm force=y format=12
@/oracle/db/admin/oracleadm/scripts/CreateDB.sql
@/oracle/db/admin/oracleadm/scripts/CreateDBFiles.sql
@/oracle/db/admin/oracleadm/scripts/CreateDBCatalog.sql
@/oracle/db/admin/oracleadm/scripts/JServer.sql
@/oracle/db/admin/oracleadm/scripts/context.sql
@/oracle/db/admin/oracleadm/scripts/ordinst.sql
@/oracle/db/admin/oracleadm/scripts/interMedia.sql
@/oracle/db/admin/oracleadm/scripts/cwmlite.sql
@/oracle/db/admin/oracleadm/scripts/spatial.sql
@/oracle/db/admin/oracleadm/scripts/apex.sql
@/oracle/db/admin/oracleadm/scripts/lockAccount.sql
@/oracle/db/admin/oracleadm/scripts/postDBCreation.sql
