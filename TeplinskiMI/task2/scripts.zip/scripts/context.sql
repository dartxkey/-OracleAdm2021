SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/context.log append
@/u01/app/oracle/product/12.2.0/darth/ctx/admin/catctx.sql Xbkfsdcdf1ggh_123 SYSAUX TEMP LOCK;
alter user CTXSYS account unlock identified by "CTXSYS";
connect "CTXSYS"/"CTXSYS"
@/u01/app/oracle/product/12.2.0/darth/ctx/admin/defaults/dr0defin.sql "RUSSIAN";
connect "SYS"/"&&sysPassword" as SYSDBA
alter user CTXSYS password expire account lock;
@/u01/app/oracle/product/12.2.0/darth/rdbms/admin/dbmsxdbt.sql;
spool off
