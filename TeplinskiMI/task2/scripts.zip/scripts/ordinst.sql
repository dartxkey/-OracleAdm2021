SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /u01/app/oracle/admin/template/scripts/ordinst.log append
@/u01/app/oracle/product/12.2.0/darth/ord/admin/ordinst.sql SYSAUX SYSAUX;
spool off
