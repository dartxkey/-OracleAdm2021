set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
host /u01/app/oracle/product/12.2.0/darth/bin/orapwd file=/u01/app/oracle/product/12.2.0/darth/dbs/orapwtemplate force=y format=12
@/u01/app/oracle/admin/template/scripts/CreateDB.sql
@/u01/app/oracle/admin/template/scripts/CreateDBFiles.sql
@/u01/app/oracle/admin/template/scripts/CreateDBCatalog.sql
@/u01/app/oracle/admin/template/scripts/JServer.sql
@/u01/app/oracle/admin/template/scripts/context.sql
@/u01/app/oracle/admin/template/scripts/ordinst.sql
@/u01/app/oracle/admin/template/scripts/interMedia.sql
@/u01/app/oracle/admin/template/scripts/cwmlite.sql
@/u01/app/oracle/admin/template/scripts/spatial.sql
@/u01/app/oracle/admin/template/scripts/sampleSchema.sql
@/u01/app/oracle/admin/template/scripts/apex.sql
@/u01/app/oracle/admin/template/scripts/lockAccount.sql
@/u01/app/oracle/admin/template/scripts/postDBCreation.sql
